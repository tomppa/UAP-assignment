// Generic lib class for file operations.

extern int opipe (int*, char*);
extern int cpipe (int*);
extern int olck (int*);
extern int clck (int*, char*);
extern int chk_log (char*);
extern int chk4lck (char*, int*);
extern int chk4pid (char*, int*);
extern int wr_pid (int, int);

